// File: src/pages/Orders.jsx
import React, { useMemo, useState } from "react";
import RecentOrdersTable from "../components/RecentOrdersTable.jsx";
import { recentOrders, orderStatuses } from "../data/orders.js";
import "./Orders.css";

export default function Orders() {
  const [activeStatus, setActiveStatus] = useState("All");

  const filteredOrders = useMemo(() => {
    if (activeStatus === "All") return recentOrders;
    return recentOrders.filter((order) => order.status === activeStatus);
  }, [activeStatus]);

  return (
    <div className="orders-page">
      <div className="orders-page-filters" role="tablist" aria-label="Filter by status">
        {["All", ...orderStatuses].map((status) => (
          <button
            key={status}
            role="tab"
            aria-selected={activeStatus === status}
            className={"orders-page-filter" + (activeStatus === status ? " is-active" : "")}
            onClick={() => setActiveStatus(status)}
          >
            {status}
          </button>
        ))}
      </div>

      <RecentOrdersTable orders={filteredOrders} />
    </div>
  );
}
