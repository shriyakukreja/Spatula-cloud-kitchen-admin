// File: src/pages/Menu.jsx
import React, { useMemo, useState } from "react";
import { menuItems, menuCategories } from "../data/menu.js";
import "./Menu.css";

export default function Menu() {
  const [activeCategory, setActiveCategory] = useState("All");

  const filteredItems = useMemo(() => {
    if (activeCategory === "All") return menuItems;
    return menuItems.filter((item) => item.category === activeCategory);
  }, [activeCategory]);

  return (
    <div className="menu-page">
      <div className="menu-page-filters">
        {menuCategories.map((category) => (
          <button
            key={category}
            className={"menu-page-filter" + (activeCategory === category ? " is-active" : "")}
            onClick={() => setActiveCategory(category)}
          >
            {category}
          </button>
        ))}
        <button className="menu-page-add">+ Add Item</button>
      </div>

      <div className="menu-grid">
        {filteredItems.map((item) => (
          <div key={item.id} className="menu-card">
            <div className="menu-card-image-wrap">
              <img src={item.image} alt={item.name} loading="lazy" />
              <span className={"menu-card-badge " + (item.available ? "is-available" : "is-unavailable")}>
                {item.available ? "Available" : "Out of Stock"}
              </span>
            </div>
            <div className="menu-card-body">
              <div className="menu-card-top">
                <h4>{item.name}</h4>
                <span className="menu-card-rating">★ {item.rating}</span>
              </div>
              <p className="menu-card-category">{item.category}</p>
              <div className="menu-card-footer">
                <span className="menu-card-price">₹{item.price}</span>
                <button className="menu-card-edit">Edit</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
