// File: src/components/StatusOverview.jsx
import React from "react";
import "./StatusOverview.css";

export default function StatusOverview({ statuses }) {
  return (
    <div className="panel status-overview-panel">
      <div className="panel-header">
        <div>
          <h3 className="panel-title">Order Status</h3>
          <p className="panel-subtitle">Live breakdown of the current kitchen queue</p>
        </div>
      </div>

      <div className="status-overview-grid">
        {statuses.map((s) => (
          <div key={s.id} className={`status-overview-card status-overview-card--${s.tone}`}>
            <span className="status-overview-count">{s.count}</span>
            <span className="status-overview-label">{s.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
