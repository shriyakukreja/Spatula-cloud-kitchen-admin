// File: src/data/customers.js
// Dummy customer snapshot data. Replace with GET /api/customers/recent.

export const recentCustomers = [
  {
    id: "cust-1",
    name: "Aarav Mehta",
    avatar: "AM",
    favouriteItem: "Butter Chicken",
    totalVisits: 42,
    lifetimeSpend: 18640,
  },
  {
    id: "cust-2",
    name: "Isha Kapoor",
    avatar: "IK",
    favouriteItem: "Paneer Tikka Wrap",
    totalVisits: 27,
    lifetimeSpend: 9820,
  },
  {
    id: "cust-3",
    name: "Rohan Verma",
    avatar: "RV",
    favouriteItem: "Mutton Biryani",
    totalVisits: 35,
    lifetimeSpend: 15230,
  },
  {
    id: "cust-4",
    name: "Sanya Malhotra",
    avatar: "SM",
    favouriteItem: "Veg Hakka Noodles",
    totalVisits: 19,
    lifetimeSpend: 6740,
  },
  {
    id: "cust-5",
    name: "Kabir Shah",
    avatar: "KS",
    favouriteItem: "Margherita Pizza",
    totalVisits: 31,
    lifetimeSpend: 11980,
  },
];
