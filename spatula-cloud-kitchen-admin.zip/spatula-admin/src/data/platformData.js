// File: src/data/platformData.js
// Dummy orders-by-platform analytics. Replace with GET /api/analytics/platforms.

export const platformAnalytics = [
  {
    id: "zomato",
    name: "Zomato",
    color: "#E23744",
    orders: 4820,
    revenue: 1284600,
    share: 38,
  },
  {
    id: "swiggy",
    name: "Swiggy",
    color: "#F6A313",
    orders: 4120,
    revenue: 1046200,
    share: 33,
  },
  {
    id: "walkin",
    name: "Walk-in",
    color: "#4FA8FF",
    orders: 2140,
    revenue: 612400,
    share: 17,
  },
  {
    id: "direct",
    name: "Direct",
    color: "#3DDC84",
    orders: 1406,
    revenue: 398100,
    share: 12,
  },
];
