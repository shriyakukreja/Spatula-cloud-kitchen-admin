// File: src/data/statusData.js
// Dummy order-status overview counts. Replace with GET /api/orders/status-summary.

export const statusOverview = [
  { id: "pending", label: "Pending", count: 23, tone: "pending" },
  { id: "preparing", label: "Preparing", count: 34, tone: "preparing" },
  { id: "ready", label: "Ready", count: 18, tone: "ready" },
  { id: "out-for-delivery", label: "Out for Delivery", count: 27, tone: "out" },
  { id: "delivered", label: "Delivered", count: 148, tone: "delivered" },
  { id: "cancelled", label: "Cancelled", count: 6, tone: "cancelled" },
];
