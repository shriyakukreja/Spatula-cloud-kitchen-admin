// File: src/data/stats.js
// Dummy statistics data for the dashboard stat cards.
// Replace with an API call (e.g. GET /api/dashboard/stats) when the backend is ready.

export const dashboardStats = [
  {
    id: "total-orders",
    label: "Total Orders",
    value: "12,486",
    change: "+8.2%",
    trend: "up",
    icon: "orders",
    caption: "All time",
  },
  {
    id: "today-orders",
    label: "Today's Orders",
    value: "184",
    change: "+12.4%",
    trend: "up",
    icon: "today",
    caption: "vs yesterday",
  },
  {
    id: "revenue-today",
    label: "Revenue Today",
    value: "₹64,920",
    change: "+5.6%",
    trend: "up",
    icon: "revenue",
    caption: "vs yesterday",
  },
  {
    id: "pending-orders",
    label: "Pending Orders",
    value: "23",
    change: "-3 orders",
    trend: "down",
    icon: "pending",
    caption: "Needs attention",
  },
  {
    id: "completed-orders",
    label: "Completed Orders",
    value: "148",
    change: "+9.1%",
    trend: "up",
    icon: "completed",
    caption: "Today",
  },
  {
    id: "avg-prep-time",
    label: "Avg. Preparation Time",
    value: "18 min",
    change: "-2 min",
    trend: "up",
    icon: "timer",
    caption: "Last 7 days",
  },
];
