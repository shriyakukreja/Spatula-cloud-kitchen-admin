// File: src/data/topSelling.js
// Dummy top selling menu items. Replace with GET /api/menu/top-selling.

export const topSellingItems = [
  {
    id: "item-1",
    name: "Butter Chicken",
    image:
      "https://images.unsplash.com/photo-1603894584373-5ac82b2ae398?w=200&h=200&fit=crop",
    orders: 1284,
    revenue: 231120,
  },
  {
    id: "item-2",
    name: "Mutton Biryani",
    image:
      "https://images.unsplash.com/photo-1631515243349-e0cb75fb8d3a?w=200&h=200&fit=crop",
    orders: 1092,
    revenue: 262080,
  },
  {
    id: "item-3",
    name: "Paneer Tikka",
    image:
      "https://images.unsplash.com/photo-1631452180519-c014fe946bc7?w=200&h=200&fit=crop",
    orders: 968,
    revenue: 145200,
  },
  {
    id: "item-4",
    name: "Margherita Pizza",
    image:
      "https://images.unsplash.com/photo-1604068549290-dea0e4a305ca?w=200&h=200&fit=crop",
    orders: 845,
    revenue: 202800,
  },
  {
    id: "item-5",
    name: "Chicken Shawarma Bowl",
    image:
      "https://images.unsplash.com/photo-1529006557810-274b9b2fc783?w=200&h=200&fit=crop",
    orders: 762,
    revenue: 132000,
  },
];
